import React from 'react';
import { typeStyles, statusColors } from './data';

const S = {
  section: {
    marginBottom: 14, padding: '10px 12px',
    background: 'rgba(255,255,255,0.02)', borderRadius: 8,
    border: '1px solid rgba(255,255,255,0.04)',
  },
  title: {
    fontSize: 9.5, fontWeight: 500, color: '#555568',
    textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 6,
  },
};

export default function DetailPanel({ node, onClose, edges, nodes }) {
  if (!node) return null;
  const d = node.data;
  const t = typeStyles[d.nodeType] || typeStyles.process;
  const connected = edges.filter(e => e.source === node.id || e.target === node.id);

  return (
    <div style={{
      position: 'fixed', right: 0, top: 0, width: 380, height: '100vh',
      background: '#0e0e18', borderLeft: '1px solid rgba(255,255,255,0.06)',
      zIndex: 100, overflowY: 'auto', padding: '20px 18px',
      fontFamily: "'JetBrains Mono', monospace",
      boxShadow: '-8px 0 30px rgba(0,0,0,0.5)',
    }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 18 }}>
        <span style={{ fontSize: 20 }}>{d.icon}</span>
        <span style={{
          fontSize: 13, fontWeight: 600, color: t.accent,
          textTransform: 'uppercase', letterSpacing: '0.5px',
        }}>{d.label}</span>
        <span onClick={onClose} style={{
          marginLeft: 'auto', cursor: 'pointer', color: '#555',
          fontSize: 16, padding: '2px 6px', borderRadius: 4,
          hover: { background: 'rgba(255,255,255,0.05)' },
        }}>✕</span>
      </div>

      {/* Status */}
      <div style={S.section}>
        <div style={S.title}>Status</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
          {(d.tags || [d.status]).map((tag, i) => {
            const c = tag.includes('live') ? '#22c55e'
              : tag.includes('broken') ? '#ef4444'
              : tag.includes('warn') ? '#f59e0b' : '#818cf8';
            return (
              <span key={i} style={{
                fontSize: 9.5, padding: '2px 8px', borderRadius: 4,
                background: `${c}15`, color: c, border: `1px solid ${c}33`,
              }}>{tag}</span>
            );
          })}
        </div>
      </div>

      {/* Description */}
      <div style={S.section}>
        <div style={S.title}>Description</div>
        <pre style={{
          fontSize: 10.5, color: '#aaa', lineHeight: 1.6,
          whiteSpace: 'pre-wrap', wordBreak: 'break-word', margin: 0,
        }}>{d.detail?.desc}</pre>
      </div>

      {/* Source */}
      <div style={S.section}>
        <div style={S.title}>Source File</div>
        <pre style={{ fontSize: 10.5, color: '#818cf8', margin: 0 }}>{d.detail?.file}</pre>
      </div>

      {/* Connections */}
      {connected.length > 0 && (
        <div style={S.section}>
          <div style={S.title}>Connections ({connected.length})</div>
          {connected.map((edge, i) => {
            const dir = edge.source === node.id ? '→' : '←';
            const otherId = edge.source === node.id ? edge.target : edge.source;
            const other = nodes.find(n => n.id === otherId);
            return (
              <div key={i} style={{
                fontSize: 10, color: edge.data?.broken ? '#f87171' : '#777',
                marginBottom: 3, cursor: 'pointer',
              }}>
                {dir} {other?.data?.label || otherId}
                {edge.data?.label ? `: ${edge.data.label}` : ''}
                {edge.data?.broken ? ' ⚠️' : ''}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
